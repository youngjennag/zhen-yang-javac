public class Main6 {
    public static void main(String[] args) {
        int price = 1000;
        System.out.println("更新前の価格：" + price + "円");
        
        price = 1200;
        System.out.println("更新後の価格：" + price + "円");
    }
}
