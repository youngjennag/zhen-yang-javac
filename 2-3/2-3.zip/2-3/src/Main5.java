public class Main5 {
    public static void main(String[] args){
        // mathScoreという変数を宣言し、85で初期化する
        int mathScore = 85;
        // mathScoreを出力する
        System.out.println("数学の点数: "+ mathScore);
    }
}
