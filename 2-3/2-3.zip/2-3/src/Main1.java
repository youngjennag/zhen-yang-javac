public class Main1 {    
    public static void main(String[] args) {
        int score = 98; // テストの点数（100点満点）
        int studentNumber = 18; // 生徒の出席番号
        boolean isPassed = true; // 合格したかどうか
        String studentName = "田中花子"; // 生徒の名前
      }
}
