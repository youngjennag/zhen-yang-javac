public class Main2 {
    public static void main(String[] args){
        System.out.println("今日の天気: 晴れ");
        System.out.println("気温: 23.5℃");
    }
}
