public class Main7 {
    public static void main(String[] args) {
        String lastName = "山田"; // 名字
        String firstName = "太郎"; // 名前
        int age = 16; // 年齢
        String emailAddress = "yamada@example.com"; // メールアドレス

        System.out.println("名前: "+ lastName + " " + firstName);
        System.out.println("年齢: "+ age + "歳");
        System.out.println("メールアドレス: "+ emailAddress);
      }
    
}
